        </article>
        <div class="height30"></div>
        <footer>
         <div class="copyright">&copy; Nittin Bushari</div>
        </footer>
    </div>
</div>
</body>
</html>

