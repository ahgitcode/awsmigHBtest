# Dynamic-website-php-sql-connectivity
In this website you know the basic CRUD operations using PHP and my SQL as database. You can perform editing, creation, deletion, read and many more operations in the database.
