			</div>
		</div>
		<div id="footer-wrapper">
			<div class="container">
				<div class="row">
					<div class="12u">
						<div id="copyright">
							<a href="#" target="_blank"> Designed by Nittin Bushari || </a> &copy;<?php echo date("Y"); ?> || All rights Reserved.
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- ********************************************************* -->
	<script src="js/config.js"></script>
    <script src="js/skel.min.js"></script>
    <script src="js/skel-panels.min.js"></script>
	</body>
</html>